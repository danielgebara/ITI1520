# ITI1520
# Daniel Gebara
# 300401006
# Exercise 1

# Entrer 2 valeurs et faire une divison et le restant
def calcul(valeur1,valeur2):
    c= valeur1//valeur2
    rest= valeur1%valeur2
    print (c, rest)