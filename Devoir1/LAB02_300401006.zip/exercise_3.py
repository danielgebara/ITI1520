# ITI1520
# Daniel Gebara
# 300401006
# Exercise 3

# Calculer la notes finale
def noteFinale(devoirsMoyenne, partiel, examen):
    ''' (float,float,float) -> float '''
    return devoirsMoyenne*0.25+partiel*0.25+examen*0.5