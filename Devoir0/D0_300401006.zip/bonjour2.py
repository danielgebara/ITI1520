# Comments
# Student name: Daniel Gebara 
# Students id: 300401006
# This program program prints a message

x = input("Quelle est votre nom?: ")
print("Bonjour", x)